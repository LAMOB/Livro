package dominando.android.ex30_googleplus;

public class Pessoa {
    public String nome;
    public String urlFoto;

    public Pessoa(String nome, String urlFoto){
        this.nome = nome;
        this.urlFoto = urlFoto;
    }
}
